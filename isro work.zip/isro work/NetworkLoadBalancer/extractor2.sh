awk 'BEGIN{FS=" "} {print $7}' client_textConfig2.txt | head -10 | tail -1 > bandwidth2.txt

