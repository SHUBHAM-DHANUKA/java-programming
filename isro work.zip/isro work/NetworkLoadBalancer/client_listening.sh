iperf3 -c 192.168.2.4 -p30000 -t3 -i1 -P1 > client_textConfig.txt
