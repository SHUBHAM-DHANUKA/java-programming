iperf3 -s -p30000 > server_output.txt
