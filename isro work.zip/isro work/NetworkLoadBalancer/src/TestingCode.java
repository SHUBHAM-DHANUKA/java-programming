import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.Scanner;

class Scriptertest1{
public void readBashScript() throws Exception {
        try {
        	// check any file exist in directory or not 
        	Runtime rt = Runtime.getRuntime() ;     
            Process p = rt.exec( "ls -A checkFolder") ; 
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            if (reader.readLine() != null) {
                System.out.println("file exist for transmission");
            // here need to code further 
                
//********************************************************************************

    			// Extract the filename and importing to bandwidth
                Process p2 = rt.exec("/home/techie-monk/eclipse-workspace/NetworkLoadBalancer/extractor.sh");    			
    			Process p3 = rt.exec("/home/techie-monk/eclipse-workspace/NetworkLoadBalancer/extractor2.sh");    			
//********************************************************************************
    			// get band width from file 
    			File file1 = new File("/home/techie-monk/eclipse-workspace/NetworkLoadBalancer/bandwidth.txt");
    			Scanner inputFile1 = new Scanner(file1);
    			float bandwidth1 = Float.parseFloat(inputFile1.next());
    			inputFile1.close();
    			
    			File file2 = new File("/home/techie-monk/eclipse-workspace/NetworkLoadBalancer/bandwidth2.txt");
    			Scanner inputFile2 = new Scanner(file2);
    			float bandwidth2 = Float.parseFloat(inputFile2.next());
    			inputFile2.close();
//********************************************************************************
		       // checking which bandwidth is good
    			// now second part  of coding start from here 
    			if ( bandwidth1 > bandwidth2) {
    				
    			System.out.println("bandwidth1 is more appripriate ");
    			}else {
    			System.out.println("bandwidth2 is more appropriate");
    			}
    		
    			
    			
    			
 //********************************************************************************

                  p2.destroy();
                  p3.destroy();
            }
            else {
            	System.out.println("no file exist for transmission");
            }

            
            p.destroy() ;
           
      } catch(Exception e) 
        {
        /*handle exception*/
           e.printStackTrace();
           throw new Exception("Error " + e.getMessage(), e.getCause());
        }
}
}
public class TestingCode{
	public static void main(String args[]) throws Exception {
		Scriptertest1 sc = new Scriptertest1();
		sc.readBashScript();
	}
}